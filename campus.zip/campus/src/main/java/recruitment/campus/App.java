package recruitment.campus;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class App 
{
	SessionFactory factory = null;
	Session session =null;
	
	public App()
	{
		System.out.println("Welcome to Recruitment Process");
    	factory = new Configuration().configure().buildSessionFactory();
    	session = factory.openSession();
    	session.beginTransaction();
	}
	
	Recruitment c =new Recruitment();
	
	public void create()
	{
		Recruitment rec1 = new Recruitment("Infi", "Java Developer", 3, 3, "Nishita"); 
		Recruitment rec2 = new Recruitment("Hero", "Developer", 2, 1, "Preston"); 
		Recruitment rec3 = new Recruitment("Neslet", "Analyst", 2, 2, "Mahananda"); 
		Recruitment rec4 = new Recruitment("Yardley", "Designer", 2, 2, "Vijeetha"); 
		  session.save(rec1); session.save(rec2);
		  session.save(rec3); session.save(rec4);
	}
	
	
	public void update()
	{
		Recruitment c=(Recruitment)session.get(Recruitment.class, 1);
		c.setExpcount(2); 
		session.update(c);
	}
	
	public void delete()
	{
		Recruitment c=(Recruitment)session.get(Recruitment.class, 3);
		 session.delete(c);
	}
	
	public void list()
	{
		Query q = session.createQuery("select people from Recruitment");
    	List<Recruitment> pool = q.list();
    	System.out.println(pool);
	}
	
	public void find()
	{
		System.out.println();
    	System.out.println();
    	Query q=session.createQuery("from Recruitment where role='Analyst' and hiredcount=Expected");
    	List<Recruitment> qu = q.list();
    	System.out.println(qu);
    	
	}

	public void end()
	{
		session.getTransaction().commit();
    	session.close();
	}
	
    public static void main( String[] args )
    {   
    	App a = new App();
    	//a.create();
    	a.update();
    //	a.delete();
    	//a.list();
    	//a.find();
    	a.end();
    }
}
